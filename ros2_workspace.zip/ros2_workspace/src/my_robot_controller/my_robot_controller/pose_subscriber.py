#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose

class Subscriber_node(Node):
    def __init__(self):
        super().__init__("pose_subscriber")
        self.pose_subscriber = self.create_subscription(Pose, '/turtle1/pose', self.callback, 10)

    def callback(self, msg:Pose):
        self.get_logger().info(str(f"X: {msg.x}, Y: {msg.y}"))    

def main(args=None):
    rclpy.init(args=args)
    node = Subscriber_node()
    rclpy.spin(node)
    rclpy.shutdown()