
"use strict";

let position = require('./position.js');

module.exports = {
  position: position,
};
