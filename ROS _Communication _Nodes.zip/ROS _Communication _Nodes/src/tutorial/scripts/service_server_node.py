import rospy
from tutorial.srv import Multiplier, MultiplierResponse

def callback(request):
    return MultiplierResponse(request.a * request.b)

def multiplication():
    rospy.init_node("service_node")
    service = rospy.service("multiplier", Multiplier, callback)
    rospy.spin()
    
if __name__=='__main__':
    multiplication()
