import rospy
from tutorial.srv import Multiplier, MultiplierResponse

def multiply_for_client(a,b):
    rospy.init_node("client_node")
    rospy.wait_for_service("multiplier")
    rate = rospy.Rate(1)

    while not rospy.is_shutdown():
        try:
            multiply_ints = rospy.ServiceProxy("multiplier", Multiplier)
            response = multiply_ints(a,b)
            rospy.loginfo(response.result)
            rate.sleep()
        except rospy.ServiceException as e:
            print(e)

if __name__ == '__main__':
    multiply_for_client(7,2)

